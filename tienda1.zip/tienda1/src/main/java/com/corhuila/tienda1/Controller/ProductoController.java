package com.corhuila.tienda1.Controller;

import com.corhuila.tienda1.Document.Producto;
import com.corhuila.tienda1.IService.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/producto")

public class ProductoController {
    @Autowired
    private IProductoService service;
    @GetMapping()
    public List<Producto> findAll(){
        return service.findAll();
    }
    @GetMapping("/{id}")
    public Optional<Producto> findById(@RequestParam String id){
        return service.findById(id);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        service.delete(id);
    }
    @PostMapping()
    public Producto save(@RequestBody Producto producto){
        return service.save(producto);
    }
    @PutMapping("/{id}")
    public void update(@RequestBody Producto producto, @PathVariable String id) {
        service.update(producto, id);
    }
}
