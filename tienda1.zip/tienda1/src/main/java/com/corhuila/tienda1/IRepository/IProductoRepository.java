package com.corhuila.tienda1.IRepository;

import com.corhuila.tienda1.Document.Categoria;
import com.corhuila.tienda1.Document.Producto;
import org.springframework.data.mongodb.core.MongoAdminOperations;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IProductoRepository extends MongoRepository <Producto, String> {
}
