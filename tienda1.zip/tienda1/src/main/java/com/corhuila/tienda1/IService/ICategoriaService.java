package com.corhuila.tienda1.IService;

import com.corhuila.tienda1.Document.Categoria;
import com.corhuila.tienda1.Document.Producto;

import java.util.List;
import java.util.Optional;

public interface ICategoriaService {
    List<Categoria> findAll();
    Optional<Categoria> findById(String id);
    Categoria save(Categoria categoria);
    void update(Categoria categoria, String id);
    void delete(String id);
}
