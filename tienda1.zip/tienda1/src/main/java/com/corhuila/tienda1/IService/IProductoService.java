package com.corhuila.tienda1.IService;

import com.corhuila.tienda1.Document.Producto;

import java.util.List;
import java.util.Optional;

    public interface IProductoService {
        List<Producto> findAll();
        Optional<Producto> findById(String id);
        Producto save(Producto producto);
        void update(Producto producto, String id);
        void delete(String id);

}
