package com.corhuila.tienda1.Service;

import com.corhuila.tienda1.Document.Producto;
import com.corhuila.tienda1.IRepository.IProductoRepository;
import com.corhuila.tienda1.IService.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoService implements IProductoService{
    @Autowired
    private IProductoRepository repository;

    @Override
    public List<Producto> findAll(){
        return repository.findAll();
    }
    @Override
    public Optional<Producto> findById(String id){
        return repository.findById(id);
    }
    @Override
    public Producto save(Producto producto){
        return repository.save(producto);
    }
    @Override
    public void update(Producto producto, String id){
        Optional<Producto> ps = repository.findById(id);
        if (!ps.isEmpty()){
            Producto productoUpdate = new Producto();
            productoUpdate.setId(id);
            productoUpdate.setNombre(producto.getNombre());
            productoUpdate.setPrecio(producto.getPrecio());
            productoUpdate.setCategoria(producto.getCategoria());
        }else{
            System.out.println("No existe el producto");
        }
    }
    @Override
    public void delete(String id){repository.deleteById(id);}
}
